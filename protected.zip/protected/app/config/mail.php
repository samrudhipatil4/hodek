<?php


return array(
   'driver' => 'smtp',
 
    'host' => 'mail.probitytech.com',
 
    'port' => 587,
 
    'from' => array('address' => 'sgt@probitytech.com', 'name' => 'Probity Change Management'),
 
     'username' => 'sgt@probitytech.com',
	'password' => 'a{=E2}udaH~I',
 
    'sendmail' => '/usr/sbin/sendmail -bs',
 
    'pretend' => false,
);


