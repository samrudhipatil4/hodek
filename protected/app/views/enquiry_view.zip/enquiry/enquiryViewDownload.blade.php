<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- <link href="<?php echo Request::root(); ?>/protected/public/css/custom-pdf.css" rel="stylesheet"> -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,700,600italic,700italic,800">
<style type="text/css">
   .report-wrapper table tbody > tr > td{
        padding: 5px !important;
        color: #58585 !important;
        font-size: 13px;
  }
</style>
</head>
<body><?php if(!empty($details)){
  foreach($details as $row){
   ?>
                           <table class="striped" border="1">
                              <tbody>
                                <tr>
                                  <td width="12.5%"><strong>Enquiry Id</strong></td>
                                  <td width="12.5%"><?php echo $row['enquiryId'];?></td>
                                  <td width="12.5%"><strong>RFQ Title</strong></td>
                                  <td width="12.5%"><?php echo $row['enquiry_no'];?></td>
                                  <td width="12.5%"><strong> Customer</strong></td>
                                  <td width="12.5%"><?php echo $row['customer'];?></td>
                                 
                                </tr>
                              
                                <tr>
                                  <td width="12.5%"><strong>Summary Description</strong></td>
                                  <td width="12.5%" colspan="3"><?php echo $row['labeling'];?></td>
                                  <td width="12.5%"><strong>Product Goals</strong></td>
                                  <td width="12.5%" colspan="3"><?php echo $row['painting'];?></td>
                                </tr>
                                  <tr>
                                   <td ><strong>Customer Contact Person</strong></td>
                                  <td colspan="3"><?php echo $row['key_competitor'];?></td>
                                   <td><strong>Phone</strong></td>
                                 <td><?php echo $row['risk_mgmt']; } ?></td>
                                  <td><strong>email</strong></td>
                                 <td><?php echo $row['file_name'];?></td>
                                 
                                </tr>
                                <tr>
                                

                                  <td><strong>instruction_for_respone</strong></td>
                                  <td >
                                        <?php echo $row['requirement_regulation'];?>
                                  </td>
                                  <td><strong>RFQ Issue Date</strong></td>
                                   <td >
                                        <?php echo $row['any_other']; ?>
                                  </td>
                                  <td><strong>Proposal Deadline</strong></td>
                                 <td><?php echo $row['proto_sample']; ?></td>
                                </tr>
                                <tr>
                                 
                                  <td><strong>Product Details</strong></td>
                                  <td>  <?php echo $row['pilot_date']; ?>
                                   </td>
                                  <td><strong>Technical Requirements</strong></td>
                                  <td>
                                        <?php echo $row['product_quality']; ?>
                                     </td>
                                      <td colspan="2"><strong>Quantity</strong></td>
                                  <td colspan="7"><?php echo $row['annual_volY5'] ?></td>
                                </tr>
                                <tr>
                                  <td><strong>Delivery Requirements</strong></td>
                                  <td colspan="3"><?php echo $row['annual_volY5'];?></td>
                                  <td><strong>Support Requirements</strong></td>
                                  <td>     <?php echo $row['annual_volY5'];?> 
                                        </td>
                                </tr>

                                <tr>
                                  <td colspan="2"><strong>Quality Assurance Requirements</strong></td>
                                  <td colspan="2"><?php echo $row['enquiry_no'];?></td>
                                  <td colspan="2"><strong>Legal Requirements</strong></td>
                                  <td colspan="2"><?php echo $row['enquiry_no'];?></td>
                                </tr>
                                <tr>
                                  <td colspan="1"><strong>Terms Condition</strong></td>
                                  <td colspan="2"><?php echo $row['enquiry_no'];?></td>
                                   <td colspan="1"><strong>Price Per Unit</strong></td>
                                   <td colspan="5"><?php echo $row['enquiry_no'];?></td>
                                </tr>
                                <tr>
                                 <td><strong>RFQ file</strong></td>
                                  <td>
                                       </td>
                                </tr>

                              </tbody>
                            </table>
<?php } ?>
                            </body>

</html>

                         

                      

  
