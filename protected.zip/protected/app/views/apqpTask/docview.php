
<iframe  src="WSDEMO/uploads/changeRequest/72607-SeriesMannual.pdf" height="900" width="800"></iframe>