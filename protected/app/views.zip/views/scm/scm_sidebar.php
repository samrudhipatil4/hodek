
<aside class="left-sidebar">
    <div class="side-box">
        <ul class="collection with-header">
            <li class="collection-header">Assigned Task</li>

            <li class="collection-item" >
                <a href="#">Add New Details</a>

            </li>
            <li class="collection-item" >

                <a href="<?php echo Request::root().'/scm/schedular' ?>">Schedule Email</a>
            </li>

        </ul>
    </div>

</aside>

