 <footer class="footer">
      <div class="footer-container">
        <div class="container">
          <div><a href="http://www.probitytech.com/" target="_blank"><img src="public/images/login/probity_logo.png" alt="Probity technologies"></a><span class="copyright">Powered By Probity Technologies 2015</span></div>
        </div>
      </div>
    </footer>



    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="public/js/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="public/js/materialize.min.js"></script>
  </body>
</html>