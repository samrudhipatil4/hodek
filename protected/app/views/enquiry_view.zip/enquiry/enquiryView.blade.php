
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0,maximum-scale=1.0, user-scalable=no">
<?php require app_path().'/views/apqp_header1.php'; ?>
<style>
table, th, td {
    
     padding: 5px 3px 5px 8px;
}
/*body {font-family: "Lato", sans-serif;}*/

/ Style the tab /
div.tab {
    overflow: hidden;
    border: 1px solid #ccc;
    background-color: #f1f1f1;
}

/ Style the buttons inside the tab /

div.tab button {
    background-color: inherit;
    float: left;
    border: none;
    outline: none;
    cursor: pointer;
    padding: 14px 16px;
    transition: 0.3s;
    font-size: 17px;
}

/ Change background color of buttons on hover /
div.tab button:hover {
    background-color: #ddd;
}

/ Create an active/current tablink class /
div.tab button.active {
    background-color: #ccc;
}

/ Style the tab content /
.tabcontent {
    display: none;
    padding: 100px 12px;
    border: 1px solid #ccc;
    border-top: none;
}
</style>
</head>
<body>
  
    <div class="page-heading">
      <h1 class="border-none">View Enquiry</h1>
    <button style="margin-top: -40px;margin-left: 150px;" class="btn btn-animate flat blue pd-btn  view_btn" type="submit" id="pdf">PDF Download</button>
     
    </div>
    <form method="get" role="form" action="" class="col-sm-12 myform" name="enquiryform" files = true id="enquiryform"  parsley-validate='' novalidate=' ' enctype="multipart/form-data">

        <div style="margin-top: -40px;margin-left: 1100px;">

    <div class="btn-wrap">
      <div class="col-sm-8">
         <select name='enquiry' id="enquiry" rows='5'  code='{$id}' class='select2 '  required  ></select>
      </div>
        <!-- <button style="margin-top: -3px;" class="btn btn-animate flat blue pd-btn  view_btn" ng-click="SearchEnquiry(requestForm,search)" type="submit">View</button> -->
      <button class="tablinks btn btn-primary btn-sm" id="view"><a href="#view_btn" action="<?php echo Request::root().'/SearchEnquiry'; ?>">View</a></button>
    </div>
    </div>
</form>
<div class="seprator"></div>
<div class="row mg-bottom-0">
                      <div class="col-sm-12">
                       <!-- ?<h4 class="border-none"><span ng-bind="summeries.c"></h4> -->
                        <h5 class="border-none" ><strong>View Enquiry:- </strong></h5>
                        <section class="report-wrapper" id="enquiry_view_id">

                           <table class="striped" id="view_btn">

                              <tbody>
                                <tr>
                                  <td width="12.5%"><strong>Enquiry Id</strong></td>
                                  <td width="12.5%"></td>

                                  <td width="12.5%"><strong>Enquiry No</strong></td>
                                  <td width="12.5%"></td>
                                  
                                  <td width="12.5%"><strong>Enquiry Date</strong></td>
                                  <td width="12.5%"><span ng-bind="summeries.enquiry_date"></span></td>
                                  
                                   <td width="12.5%"><strong>Customer</strong></td>
                                  <td width="12.5%"><span ng-bind="summeries.customer"></span></td>
                                  <td width="12.5%"><strong>Customer Revision Number</strong></td>
                                  <td width="12.5%"><span ng-bind="summeries.cust_rev"></span></td>
                                  <td width="12.5%"><strong>Customer Part Number</strong></td>
                                  <td width="12.5%"><span ng-bind="summeries.cust_part_no"></span></td>
                                  <td width="12.5%"><strong>Customer Contact Person</strong></td>
                                  <td width="12.5%"><span ng-bind="summeries.cust_cont_person"></span></td>                               
                                </tr>
                                <tr>
                                <tr>
                                  <td><strong>Customer contact Number</strong></td>
                                  <td width="12.5%" colspan="3"><span ng-bind="summeries.cust_person_no"></span></td>
                                  <td width="12.5%"><strong>Customer Person Email</strong></td>
                                  <td width="12.5%" colspan="3"><span ng-bind="summeries.cust_person_email"></span></td>
                                </tr>

                                   <td ><strong>Engine Details</strong></td>
                                  <td ><span ng-bind="summeries.engine_details"></span></td>
                                  <td><strong>Engine Application Details</strong></td>
                                 <td><span ng-bind="summeries.engine_appl_details"></span></td>
                                 <td><strong>Similar Product Mfg</strong></td>
                                 <td><span ng-bind="summeries.similar_product_mfg"></span></td>
                                 <td><strong>Internal Customer Name</strong></td>
                                 <td><span ng-bind="summeries.internal_cust"></span></td>

                                </tr>
                                <tr>

                                  <td><strong>Estimated Cost Of Damper</strong></td>
                                  <td colspan="2">
                                        <span ng-bind="summeries.estimated_cost"></span>
                                  </td>
                                  <td><strong>Proposal Deadline</strong></td>
                                   <td >
                                         <span ng-bind="summeries.deadline"></span>
                                  </td>
                                  <td><strong>Annual Volume YR1</strong></td>
                                 <td><span ng-bind="summeries.annual_volY1"></span></td>
                                </tr>
                                <tr>
                                 
                                  <td><strong>Annual Volume YR2</strong></td>
                                  <td colspan="2">  <span ng-bind="summeries.annual_volY2"></span>
                                   </td>
                                  <td><strong>Annual Volume YR3</strong></td>
                                  <td colspan="2">
                                        <span ng-bind="summeries.annual_volY3"></span>
                                     </td>
                                      <td ><strong>Annual Volume YR4</strong></td>
                                  <td ><span ng-bind="summeries.annual_volY14"></span></td>
                                </tr>
                                <tr>
                                  <td><strong>Annual Volume YR5</strong></td>
                                  <td colspan="2"><span ng-bind="summeries.annual_volY5"></span></td>
                                  <td><strong>Prototype Sample</strong></td>
                                  <td colspan="2"><span ng-bind="summeries.proto_sample"></span></td>
                                </tr>
                                <tr>
                                  <td><strong>Prototype Date</strong></td>
                                  <td colspan="2"><span ng-bind="summeries.proto_date"></span></td>
                                  <td><strong>PILOT Batch</strong></td>
                                  <td colspan="2"><span ng-bind="summeries.pilot_batch"></span> </td>
                                </tr>
                                <tr>
                                  <td><strong>PILOT Date</strong></td>
                                  <td colspan="2"><span ng-bind="summeries.pilot_date"></span></td>
                                  <td><strong>PPAP Batch</strong></td>
                                  <td colspan="2"><span ng-bind="summeries.ppap_batch"></span> 
                                </td>
                                </tr>
                                  <td colspan="1"><strong>PPAP Date</strong></td>
                                  <td colspan="2"><span ng-bind="summeries.ppap_date"></span></td>
                                   <td colspan="1"><strong>SOP Date</strong></td>
                                   <td colspan="5"><span ng-bind="summeries.sop_date"></span></td>
                                </tr>
                                <tr>
                                  <td colspan="1"><strong>Packaging</strong></td>
                                  <td colspan="2"><span ng-bind="summeries.packaging"></span></td>
                                   <td colspan="1"><strong>Labeling</strong></td>
                                   <td colspan="5"><span ng-bind="summeries.labeling"></span></td>
                                </tr>
                                <tr>
                                  <td colspan="1"><strong>Painting</strong></td>
                                  <td colspan="2"><span ng-bind="summeries.painting"></span></td>
                                   <td colspan="1"><strong>Any Other</strong></td>
                                   <td colspan="5"><span ng-bind="summeries.any_other"></span></td>
                                </tr>
                                <tr>
                                  <td colspan="1"><strong>Engine Data Sheet</strong></td>
                                  <td colspan="2"><span ng-bind="summeries.engine_data"></span></td>
                                  <td colspan="1"><strong>Customer Specific Requirement</strong></td>
                                   <td colspan="5"><span ng-bind="summeries.specific_req"></span></td>
                                </tr>
                                <tr>
                                  <td colspan="1"><strong>Customer Interview</strong></td>
                                  <td colspan="2"><span ng-bind="summeries.cust_interview"></span></td>
                                   <td colspan="1"><strong>Name of the Interviewee</strong></td>
                                   <td colspan="5"><span ng-bind="summeries.name_interview"></span></td>
                                </tr>
                                <tr>
                              <td colspan="1"><strong>Name of the Interviewer</strong></td>
                                  <td colspan="2"><span ng-bind="summeries.name_interviewer"></span></td>
                                   <td colspan="1"><strong>Inputs/Data Collected</strong></td>
                                   <td colspan="5"><span ng-bind="summeries.input_data"></span></td>
                                </tr>
                                <tr>
                                  <td colspan="1"><strong>Competitors Name</strong></td>
                                  <td colspan="2"><span ng-bind="summeries.competitors"></span></td>
                                   <td colspan="1"><strong>Product Name</strong></td>
                                   <td colspan="5"><span ng-bind="summeries.product_name"></span></td>
                                </tr>
                                <tr>
                                  <td colspan="1"><strong>Product & Quality Information</strong></td>
                                  <td colspan="2"><span ng-bind="summeries.product_quality"></span></td>
                                   <td colspan="1"><strong>TGR Reports</strong></td>
                                   <td colspan="5"><span ng-bind="summeries.tgr_report"></span></td>
                                </tr>
                                <tr>
                                  <td colspan="1"><strong>TGW Product/Name</strong></td>
                                  <td colspan="2"><span ng-bind="summeries.tgw_product_name"></span></td>
                                   <td colspan="1"><strong>Discrepancy Observed</strong></td>
                                   <td colspan="5"><span ng-bind="summeries.discrepancy"></span></td>
                                </tr>
                                <tr>
                                  <td colspan="1"><strong>Probable Causes for Discrepancy</strong></td>
                                  <td colspan="2"><span ng-bind="summeries.cause_discrepancy"></span></td>
                                   <td colspan="1"><strong>Customer plant returns & Rejection</strong></td>
                                   <td colspan="5"><span ng-bind="summeries.return_reject"></span></td>
                                </tr>
                                <tr>
                                  <td colspan="1"><strong>Field return Product Analysis</strong></td>
                                  <td colspan="2"><span ng-bind="summeries.field_return"></span></td>
                                   <td colspan="1"><strong>Customer Letters/suggestion</strong></td>
                                   <td colspan="5"><span ng-bind="summeries.cust_suggestions"></span></td>
                                </tr>
                                <tr>
                                  <td colspan="1"><strong>Field service reports</strong></td>
                                  <td colspan="2"><span ng-bind="summeries.service_report"></span></td>
                                   <td colspan="1"><strong>Transportation & Primiunm Freight</strong></td>
                                   <td colspan="5"><span ng-bind="summeries.transportation"></span></td>
                                </tr>
                                <tr>
                                  <td colspan="1"><strong>Goverment requirements & regulations:</strong></td>
                                  <td colspan="2"><span ng-bind="summeries.requirement_regulation"></span></td>
                                   <td colspan="1"><strong>Problems & issues Report from Internal customer</strong></td>
                                   <td colspan="5"><span ng-bind="summeries.internal_custo"></span></td>
                                </tr>
                                <tr>
                                  <td colspan="1"><strong>TGR/TGW</strong></td>
                                  <td colspan="2"><span ng-bind="summeries.tgr_tgw"></span></td>
                                   <td colspan="1"><strong>Time constriants</strong></td>
                                   <td colspan="5"><span ng-bind="summeries.time_constriants"></span></td>
                                </tr>
                                <tr>
                                  <td colspan="1"><strong>Cost constraint</strong></td>
                                  <td colspan="2"><span ng-bind="summeries.cost_constraint"></span></td>
                                   <td colspan="1"><strong>Investment</strong></td>
                                   <td colspan="5"><span ng-bind="summeries.investment"></span></td>
                                </tr>
                                <tr>
                                  <td colspan="1"><strong>key competitors</strong></td>
                                  <td colspan="2"><span ng-bind="summeries.key_competitor"></span></td>
                                   <td colspan="1"><strong>Performance</strong></td>
                                   <td colspan="5"><span ng-bind="summeries.performance"></span></td>
                                </tr>
                                <tr>
                                  <td colspan="1"><strong>Cost</strong></td>
                                  <td colspan="2"><span ng-bind="summeries.Cost"></span></td>
                                   <td colspan="1"><strong>New Technology</strong></td>
                                   <td colspan="5"><span ng-bind="summeries.n_techno"></span></td>
                                </tr>
                                <tr>
                                  <td colspan="1"><strong>New resources</strong></td>
                                  <td colspan="2"><span ng-bind="summeries.new_resources"></span></td>
                                   <td colspan="1"><strong>Risk Management</strong></td>
                                   <td colspan="5"><span ng-bind="summeries.risk_mgmt"></span></td>
                                </tr>                           
                              </tbody>

                            </table>
                        </section>

</div>
</div>


<script type="text/javascript">
    var base_url='<?php echo Request::root(); ?>/';
     $.ajax({
         url:base_url+'getEnq',
         type:'post',
         data:{},
         success:function(data){
             $("#enquiry").html(data);
         }
     });

      $("#view").click(function(evt){
          var enquiry =$("#enquiry").val();
          if(enquiry == ''){
            alert('Select enquiry');
            }else{
           
          evt.preventDefault();
             
            $.ajax({
                    url:base_url+'SearchEnquiry',
                    type: 'POST',
                    data:new FormData($("#enquiryform")[0]),
                    contentType: false,
                    cache: false,
                    processData:false,
                    dataType:"HTML",
                    beforeSend: function(){
                     $("#fade").show();
                    },
                    success: function (data) {
                         $("#enquiry_view_id").html('');
                         $("#enquiry_view_id").html(data);
                    }
                
                 });
              }
       });
   $("#pdf").click(function(evt){
          var enquiry =$("#enquiry").val();
          // if(enquiry == ''){
          //   alert('Select enquiry');
          //   }else{
           
          evt.preventDefault();
             
            $.ajax({
                    url:base_url+'downloadEnquiryView',
                    type: 'POST',
                    data:new FormData($("#enquiryform")[0]),
                    contentType: false,
                    cache: false,
                    processData:false,
                    dataType:"HTML",
                    beforeSend: function(){
                     $("#fade").show();
                    },
                    success: function (data) {
                         $("#fade").html('');
                         //$("#enquiry_view_id").html(data);
                    }
                
                 });
              // }
       });
   

</script>
</body>
</html>