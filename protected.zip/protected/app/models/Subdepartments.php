<?php

class Subdepartments extends Eloquent {
	protected $fillable = array('sub_dep_id', 'sub_dep_name','department_id');	
}
