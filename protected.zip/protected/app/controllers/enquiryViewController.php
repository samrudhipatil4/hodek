<?php

class enquiryViewController extends BaseController  
{
    public function viewEnquiry()
    {
        if(Auth::check()):
              return View::make('enquiry/enquiryView');
        else:
             return Redirect::to('')->with('message', SiteHelpers::alert('error','Please Login to Access this Page'));
          endif;
    }

    public function getEnq()
    {
      $data = DB::select(DB::raw('select enquiryId,enquiry_no from customer_enquiry_form'));
       $select = "--Please Select--";
            echo '<option value="">';
            echo $select.'</option>';
            foreach($data as $d){
              echo '<option value="'.$d->enquiryId.'"';
              echo '>'.$d->enquiry_no.'</option>';
            }
    exit();
    }

  public function SearchEnquiry()
  {
    $input =Input::all();
    $en = new Enquiry();
    $enquiry = $input['enquiry'];
    $enquiry_data= $en->getEnquiryData($enquiry);
    $file_data= $en->getEnquiryFileData($enquiry);
    return View::make('enquiry.enquiryViewAjax', array('enquiry_details' => $enquiry_data,'file_details' => $file_data));    
  }

  public function enquiryPDFDownload(){
    $input =Input::all();
    $en = new Enquiry();
    $enquiry = $input['enquiry'];
    $enquiry_data = $en->getEnquiryData($enquiry);
    $file_data = $en->getEnquiryFileData($enquiry);
    $date = date('Y-m-d');
    $filename ='enquiryPDF-'.$date;
    $pdf=PDF::loadView('enquiry.enquiryViewDownload', array('enquiry_details' => $enquiry_data,'file_details' => $file_data))->save('uploads/'.$filename.'.pdf',true);
    $pdf->setPaper('a2')->setOrientation('landscape')->setWarnings(false);

    echo 'uploads/'.$filename.'.pdf';
    }

    public function enquiryExcelDownload(){
    $input =Input::all();
    $en = new Enquiry();
    $enquiry = $input['enquiry'];
    $enquiry_data= $en->getEnquiryData($enquiry);
    $file_data= $en->getEnquiryFileData($enquiry);
    $date = date('Y-m-d');
    $filename='enqquiryExcel-'.$date;
    
    $output = View::make('enquiry.enquiryExcelDownload',array('enquiry_details' => $enquiry_data,'file_details' => $file_data));
    // dd($output);
   /* $headers = array(
                    'Pragma' => 'public',
                    'Expires' => 'public',
                    'Cache-Control' => 'must-revalidate, post-check=0, pre-check=0',
                    'Cache-Control' => 'private',
                    // 'Content-Type' => 'application/vnd.ms-excel; name="excel"',
                    'Content-Type: text/csv',
                    'Content-Disposition' => 'attachment; filename='.$filename.'.xls',
                    'Content-Transfer-Encoding' => 'binary'
                );
*/
      header('Content-Type:application/xls');
      header('Content-Disposition: attachment; filename=products.xls');
          echo "Duplicate data";


    // echo 'uploads/'.$filename.'.xls';
    // return Response::make($output, 200, $headers);
    }

}

