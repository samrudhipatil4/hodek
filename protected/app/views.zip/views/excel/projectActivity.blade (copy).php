<?php //print_r($activities);die; ?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>






</head>

<body>
<div class="container">
<div class="col-md-12">
<div class="table-container">

<div>
  <h4>Project NO : Project-544</h4>
  <h4>Project Name : Projct name111</h4>
  <h4>Manufacturing Location : Pune Production</h4>
  <h4>Project Start Date : 11 April 17</h4>
</div>
<table class="table table-responsive table-bordered">
 <tr class="table-heading">
    <th>Sr.No</th>
    <th>Gate</th> 
    <th>Activity</th>
    <th>Responsibility</th>
     <th></th>
     <th>Duration</th>
     <th>Activity<br> Start Date</th>
     <th>Activity<br> End Date</th>
          <th class="">11 April 17</th>
          <th class="">12 April 17</th>
          <th class="">13 April 17</th>
          <th class="">14 April 17</th>
          <th class="">15 April 17</th>
          <th class="">16 April 17</th>
          <th class="">17 April 17</th>
          <th class="">18 April 17</th>
          <th class="">19 April 17</th>
          <th class="">20 April 17</th>
          <th class="">21 April 17</th>
          <th class="">22 April 17</th>
          <th class="">23 April 17</th>
          <th class="">24 April 17</th>
          <th class="">25 April 17</th>
          <th class="">26 April 17</th>
          <th class="">27 April 17</th>
          <th class="">28 April 17</th>
          <th class="">29 April 17</th>
          <th class="">30 April 17</th>
          <th class="">01 May 17</th>
          <th class="">02 May 17</th>
          <th class="">03 May 17</th>
          <th class="">04 May 17</th>
          <th class="">05 May 17</th>
          <th class="">06 May 17</th>
          <th class="">07 May 17</th>
          <th class="">08 May 17</th>
          <th class="">09 May 17</th>
          <th class="">10 May 17</th>
          <th class="">11 May 17</th>
              <!-- <th class="vertical">1 st May 2017</th>
     <th class="vertical">2 st May 2017</th>
     <th class="vertical">3 st May 2017</th>
     <th class="vertical">4 st May 2017</th>
     <th class="vertical">5 st May 2017</th>-->
  </tr>
       <tr>
    <td style="color:red">1.33</td>
    <td >Plan and Define Program</td>
    <td >gate 1commom</td>
    <td>Manufacturing</td>
    <td>
        <table class="sub-table" width="100%">
          <tr><td class="border-button">Plan</td></tr>
          <tr><td>Actual</td></tr>
        </table>
    </td>
    <td>
        <table class="sub-table" width="100%">
          <tr><td class="border-button">3</td></tr>
          <tr><td></td></tr>
        </table>
    </td>
    <td>
        <table class="sub-table" width="100%">
          <tr><td class="border-button">11 April 17</td></tr>
          <tr><td></td></tr>
        </table>
    </td>
    <td>
        <table class="sub-table" width="100%">
          <tr><td class="border-button" >14 April 17</td></tr>
          <tr><td></td></tr>
        </table>
    </td>
        <td >
        <table class="sub-table" width="100%">
        
                      <tr><td  class="border-button red-background" style="background-color:#ccc"></td></tr>
          
                      <tr><td  class=" "></td></tr>
          
                    
        </table>
    </td>
         <td >
        <table class="sub-table" width="100%">
        
                      <tr><td  class="border-button red-background"></td></tr>
          
                      <tr><td  class=" "></td></tr>
          
                    
        </table>
    </td>
         <td >
        <table class="sub-table" width="100%">
        
                      <tr><td  class="border-button red-background"></td></tr>
          
                      <tr><td  class=" "></td></tr>
          
                    
        </table>
    </td>
         <td >
        <table class="sub-table" width="100%">
        
                      <tr><td  class="border-button red-background"></td></tr>
          
                      <tr><td  class=" "></td></tr>
          
                    
        </table>
    </td>
         <td >
        <table class="sub-table" width="100%">
        
                      <tr><td  class="border-button "></td></tr>
          
                      <tr><td  class=" "></td></tr>
          
                    
        </table>
    </td>
         <td >
        <table class="sub-table" width="100%">
        
                      <tr><td  class="border-button "></td></tr>
          
                      <tr><td  class=" "></td></tr>
          
                    
        </table>
    </td>
         <td >
        <table class="sub-table" width="100%">
        
                      <tr><td  class="border-button "></td></tr>
          
                      <tr><td  class=" "></td></tr>
          
                    
        </table>
    </td>
         <td >
        <table class="sub-table" width="100%">
        
                      <tr><td  class="border-button "></td></tr>
          
                      <tr><td  class=" "></td></tr>
          
                    
        </table>
    </td>
         <td >
        <table class="sub-table" width="100%">
        
                      <tr><td  class="border-button "></td></tr>
          
                      <tr><td  class=" "></td></tr>
          
                    
        </table>
    </td>
         <td >
        <table class="sub-table" width="100%">
        
                      <tr><td  class="border-button "></td></tr>
          
                      <tr><td  class=" "></td></tr>
          
                    
        </table>
    </td>
         <td >
        <table class="sub-table" width="100%">
        
                      <tr><td  class="border-button "></td></tr>
          
                      <tr><td  class=" "></td></tr>
          
                    
        </table>
    </td>
         <td >
        <table class="sub-table" width="100%">
        
                      <tr><td  class="border-button "></td></tr>
          
                      <tr><td  class=" "></td></tr>
          
                    
        </table>
    </td>
         <td >
        <table class="sub-table" width="100%">
        
                      <tr><td  class="border-button "></td></tr>
          
                      <tr><td  class=" "></td></tr>
          
                    
        </table>
    </td>
         <td >
        <table class="sub-table" width="100%">
        
                      <tr><td  class="border-button "></td></tr>
          
                      <tr><td  class=" "></td></tr>
          
                    
        </table>
    </td>
         <td >
        <table class="sub-table" width="100%">
        
                      <tr><td  class="border-button "></td></tr>
          
                      <tr><td  class=" "></td></tr>
          
                    
        </table>
    </td>
         <td >
        <table class="sub-table" width="100%">
        
                      <tr><td  class="border-button "></td></tr>
          
                      <tr><td  class=" "></td></tr>
          
                    
        </table>
    </td>
         <td >
        <table class="sub-table" width="100%">
        
                      <tr><td  class="border-button "></td></tr>
          
                      <tr><td  class=" "></td></tr>
          
                    
        </table>
    </td>
         <td >
        <table class="sub-table" width="100%">
        
                      <tr><td  class="border-button "></td></tr>
          
                      <tr><td  class=" "></td></tr>
          
                    
        </table>
    </td>
         <td >
        <table class="sub-table" width="100%">
        
                      <tr><td  class="border-button "></td></tr>
          
                      <tr><td  class=" "></td></tr>
          
                    
        </table>
    </td>
         <td >
        <table class="sub-table" width="100%">
        
                      <tr><td  class="border-button "></td></tr>
          
                      <tr><td  class=" "></td></tr>
          
                    
        </table>
    </td>
         <td >
        <table class="sub-table" width="100%">
        
                      <tr><td  class="border-button "></td></tr>
          
                      <tr><td  class=" "></td></tr>
          
                    
        </table>
    </td>
         <td >
        <table class="sub-table" width="100%">
        
                      <tr><td  class="border-button "></td></tr>
          
                      <tr><td  class=" "></td></tr>
          
                    
        </table>
    </td>
         <td >
        <table class="sub-table" width="100%">
        
                      <tr><td  class="border-button "></td></tr>
          
                      <tr><td  class=" "></td></tr>
          
                    
        </table>
    </td>
         <td >
        <table class="sub-table" width="100%">
        
                      <tr><td  class="border-button "></td></tr>
          
                      <tr><td  class=" "></td></tr>
          
                    
        </table>
    </td>
         <td >
        <table class="sub-table" width="100%">
        
                      <tr><td  class="border-button "></td></tr>
          
                      <tr><td  class=" "></td></tr>
          
                    
        </table>
    </td>
         <td >
        <table class="sub-table" width="100%">
        
                      <tr><td  class="border-button "></td></tr>
          
                      <tr><td  class=" "></td></tr>
          
                    
        </table>
    </td>
         <td >
        <table class="sub-table" width="100%">
        
                      <tr><td  class="border-button "></td></tr>
          
                      <tr><td  class=" "></td></tr>
          
                    
        </table>
    </td>
         <td >
        <table class="sub-table" width="100%">
        
                      <tr><td  class="border-button "></td></tr>
          
                      <tr><td  class=" "></td></tr>
          
                    
        </table>
    </td>
         <td >
        <table class="sub-table" width="100%">
        
                      <tr><td  class="border-button "></td></tr>
          
                      <tr><td  class=" "></td></tr>
          
                    
        </table>
    </td>
         <td >
        <table class="sub-table" width="100%">
        
                      <tr><td  class="border-button "></td></tr>
          
                      <tr><td  class=" "></td></tr>
          
                    
        </table>
    </td>
         <td >
        <table class="sub-table" width="100%">
        
                      <tr><td  class="border-button "></td></tr>
          
                      <tr><td  class=" "></td></tr>
          
                    
        </table>
    </td>
             
    </tr>
        
  
  
</table>
</div>
</div>
</div>
</body>
</html>


