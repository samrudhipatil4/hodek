<?php

return array(

	/*
	|--------------------------------------------------------------------------
	| API Keys
	|--------------------------------------------------------------------------
	|
	| Set the public and private API keys as provided by reCAPTCHA.
	|
	*/
	'public_key'	=> '6Ldg6_ISAAAAAGn4r9WpJwL7jEameeErktf4Jjos',
	'private_key'	=> '6Ldg6_ISAAAAAMsBDL9GqFq4t5kQzCAOuYFsyKhN',
	
	/*
	|--------------------------------------------------------------------------
	| Template
	|--------------------------------------------------------------------------
	|
	| Set a template to use if you don't want to use the standard one.
	|
	*/
	'template'		=> '',
	
);